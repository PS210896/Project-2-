//==========================================================================//
//=====================    Huur fietsen op fietsenverhuur    ===========//
//==========================================================================//
function rentCheckedProducts()
{
  //checkboxen defineren met bijbehorende ID
  var checkboxA = document.getElementById("aanhang");
  
  var checkboxB = document.getElementById("bak");

  var checkboxC = document.getElementById("driewieler");

  var checkboxD = document.getElementById("eletrische");

  var checkboxE = document.getElementById("kinder");

  var checkboxF = document.getElementById("lig");

  var checkboxG = document.getElementById("oma");

  var checkboxH = document.getElementById("race");

  var checkboxI = document.getElementById("speed");

  var checkboxJ = document.getElementById("stads");

  var checkboxK = document.getElementById("vouw");

  var checkboxL = document.getElementById("zit");

    //als de eerste checkbox gechecked is dan...
    if (checkboxA.checked )
    {
      
      var cbAtext = document.getElementById("aanhang2").innerText;
      localStorage.setItem("textvalues",cbAtext);
      window.open("Klantengegevens.html")
      return false;
      //de gegevens van aanhang2 word een variabele van gemaakt en die worden opgeslagen in de local storage "textvalues" zodat je ze op klantgegevens.html kunt gebruiken
      
    }
    else if (checkboxB.checked) 
    {
      var cbBtext = document.getElementById("bak2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxC.checked) 
    {
      var cbBtext = document.getElementById("driewieler2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxD.checked) 
    {
      var cbBtext = document.getElementById("elektrische2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxE.checked) 
    {
      var cbBtext = document.getElementById("kinder2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxF.checked) 
    {
      var cbBtext = document.getElementById("lig2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxG.checked) 
    {
      var cbBtext = document.getElementById("oma2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxH.checked) 
    {
      var cbBtext = document.getElementById("race2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxI.checked) 
    {
      var cbBtext = document.getElementById("speed2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxJ.checked) 
    {
      var cbBtext = document.getElementById("stads2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxK.checked) 
    {
      var cbBtext = document.getElementById("vouw2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else if (checkboxL.checked) 
    {
      var cbBtext = document.getElementById("zit2").innerText;

      localStorage.setItem("textvalues",cbBtext);
      window.open("Klantengegevens.html")
      return false;
    }
    else 
    {
       alert("Selecteer een fiets aub.")
    } 
}
//==========================================================================//
//======================= Aanpassen H2 voor tijden op homepage =============//
//==========================================================================//
  var myDate = new Date();

  // 0 = Zondag, 1 = Maandag etc.
  var day = myDate.getDay();

  //triggered de functie
  displayOpeninghours() 


function displayOpeninghours() 
{
  
  if (day =="1" && myDate.getHours() > 12.5 && myDate.getHours() < 18)
  {
    document.getElementById("Winkel").innerHTML = "We zijn open en staan klaar om klanten te ontvangen!"
    //Als het maandag is en de tijd is tussen 12:30 en 18:00 dan is de winkel open
  }
  else if (day =="2" && myDate.getHours() > 8 && myDate.getHours() < 18) 
  {
    document.getElementById("Winkel").innerHTML = "We zijn open en staan klaar om klanten te ontvangen!"
    //Als het disndag is en de tijd is tussen 8:00 en 18:00 dan is de winkel open
  }
  else if (day =="3" || day =="4" && myDate.getHours() > 8.5 && myDate.getHours() < 18) 
  {
    document.getElementById("Winkel").innerHTML = "We zijn open en staan klaar om klanten te ontvangen!"
    //Als het woensdag of donderdag (deze hebben dezelfde openingstijden) is en de tijd is tussen 8:30 en 18:00 dan is de winkel open
  }
  else if (day =="5" && myDate.getHours() > 8.5 && myDate.getHours() < 19.5) 
  {
    document.getElementById("Winkel").innerHTML = "We zijn open en staan klaar om klanten te ontvangen!"
    //Als het vrijdag is en de tijd is tussen 8:30 en 19:30 dan is de winkel open
  }
  else if (day =="6" && myDate.getHours() > 9 && myDate.getHours() < 17) 
  {
    document.getElementById("Winkel").innerHTML = "We zijn open en staan klaar om klanten te ontvangen!"
    //Als het zaterdag is en de tijd is tussen 9 en 17:00 dan is de winkel open
  }
  else
  {
    document.getElementById("Winkel").innerHTML = "We zijn gesloten, helaas ontvangen we momenteel geen klanten meer"
  }
    //Als geen van de bovenstaande condities waar zijn dan zijn we gesloten
}