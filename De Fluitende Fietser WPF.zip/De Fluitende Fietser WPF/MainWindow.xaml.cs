﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Threading;
using System.ComponentModel;


namespace De_Fluitende_Fietser_CSharp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //hier maken we de timer aan
        DispatcherTimer timer = new DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();
            //de timer wordt gedefineerd
            var timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1000);
            timer.Tick += tmr_AFK;
            timer.Start();

        }
        //de bar aan de rechterkant van het scherm
        int AFKcounter = 100;
        private void tmr_AFK(object sender, EventArgs e)
        {
            //zodat de bar kleiner en kleinr wordt
            ProgressBar.Value = AFKcounter;
            //er gaat steeds 1 value vanaf
            AFKcounter -= 1;
            //als de timer kleiner dan 1 wordt dan...
            if (AFKcounter < 1)
            {
                MessageBox.Show("U bent een minuut lang inactief geweest, het scherm gaat nu sluiten");
                this.Close();
            }
            timer.Start();
            InputManager.Current.PostProcessInput += delegate (object s, ProcessInputEventArgs r)
            {
                //als de gebruiker een item aanraakt op het scherm dan wordt de timer gereset naar nog een minuut.
                if (r.StagingItem.Input is MouseButtonEventArgs || r.StagingItem.Input is KeyEventArgs)
                    AFKcounter = 100;
                    timer.Interval = TimeSpan.FromSeconds(60);
            };
        }

        double totaalprijs = 0.00; //voor de totaalprijs bij de listbox
        private void Bestellen_Click(object sender, RoutedEventArgs e)
        {
            //we gebruiken een try and catch om een crash te voorkomen waarbij de applicatie stop als je iets anders dan een nummer invoert bij tbAantal
            try
            {
                if (cbFietsen.SelectedItem != null && cbFietsen.SelectedItem != blank)
                {
                    Toevoegen_Listbox();
                }
                else if (cbServices.SelectedItem !=null && cbServices.SelectedItem != blank3)
                {
                    Toevoegen_Listbox();
                }
                else if (cbVerzekeringen.SelectedItem != null & cbVerzekeringen.SelectedItem != blank2)
                {
                    Toevoegen_Listbox();
                }
                else
                {
                    MessageBox.Show("Selecteer een Item");
                    return;
                }
            }


            catch
            {
                MessageBox.Show("Voer een geldig getal in");
            }
        }
        
        private void LB_DeleteItemClick(object sender, MouseButtonEventArgs e)
        {
            //Er verschijnt een messagebox wanneer er wordt gedubbelklikt, als je op "Yes" drukt dan wordt het artikel verwijdert.
            if (MessageBox.Show("Weet je zeker dat je het artikel wilt verwijderen?", "", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                Listbox.Items.RemoveAt(Listbox.SelectedIndex);

            else
            {
                return;
            }
        }
        private void Toevoegen_Listbox ()
        {
            //We maken variabelen voor alle comboboxen en het invoerveld van aantal dagen
            var fiets = cbFietsen.Text.ToString();
            var verzekering = cbVerzekeringen.Text.ToString();
            var services = cbServices.Text.ToString();
            var aantal = tbAantal.Text.ToString();

            //We gebruiken doubles zodat er gerekent kan worden met precieze komma getallen.
            //We maken voor iedere fiets een double met de exacte prijs van de fiets voor een dag
            double dag = double.Parse(aantal);
            double aanhangfiets = 20 * dag;
            double bakfiets = 35 * dag;
            double driewieler = 30 * dag;
            double elektrisch = 30 * dag;
            double kinderfiets = 15 * dag;
            double ligfiets = 45 * dag;
            double omafiets = 12.50 * dag;
            double racefiets = 15 * dag;
            double speed = 15 * dag;
            double stadsfiets = 12.50 * dag;
            double vouwfiets = 10 * dag;
            double zitfiets = 15 * dag;
            


            //Switch case voor elke situatie die voorkomt in de fiets combobox.

            switch (fiets)
            {
                case "Aanhangfiets € 20,00":

                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + aanhangfiets);
                    totaalprijs += aanhangfiets;
                    break;

                case "Bakfiets € 35,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + bakfiets);
                    totaalprijs += bakfiets;
                    break;

                case "Driewielfiets € 30,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + driewieler);
                    totaalprijs += driewieler;
                    break;

                case "Elektrische fiets € 30,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + elektrisch);
                    totaalprijs += elektrisch;
                    break;

                case "Kinderfiets € 15,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + kinderfiets);
                    totaalprijs += kinderfiets;
                    break;

                case "Ligfiets € 45,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + ligfiets);
                    totaalprijs += ligfiets;
                    break;

                case "Oma fiets € 12,50":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + omafiets);
                    totaalprijs += omafiets;
                    break;

                case "Racefiets	€ 15,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + racefiets);
                    totaalprijs += racefiets;
                    break;

                case "Speed pedelec	€ 15,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + speed);
                    totaalprijs += speed;
                    break;

                case "Stadsfiets € 12,50":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + stadsfiets);
                    totaalprijs += stadsfiets;
                    break;

                case "Vouwfiets	€ 10,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + vouwfiets);
                    totaalprijs += vouwfiets;
                    break;

                case "Zitfiets € 15,00":
                    Listbox.Items.Add(fiets + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + zitfiets);
                    totaalprijs += zitfiets;
                    break;
            }

            //per verzekering een double 
            double beschadigingen = 5.00 * dag;
            double diefstal = 10.00 * dag;
            double rechtsbijstand = 5.00 * dag;
            double ongevallen = 2.50 * dag;

            //switch case voor elke situatie die voorkomt in de verzekeringen combobox
            switch (verzekering)
            {
                case "Beschadigingen € 5,00":
                    Listbox.Items.Add(verzekering + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + beschadigingen);
                    totaalprijs += beschadigingen;
                    break;

                case "Diefstal € 10,00":
                    Listbox.Items.Add(verzekering + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + diefstal);
                    totaalprijs += diefstal;
                    break;

                case "Rechtsbijstand € 5,00":
                    Listbox.Items.Add(verzekering + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + rechtsbijstand);
                    totaalprijs += rechtsbijstand;
                    break;

                case "Ongevallen € 2,50":
                    Listbox.Items.Add(verzekering + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + ongevallen);
                    totaalprijs += ongevallen;
                    break;
            }

            //per service een double
            double ophaalservice = 15.00 * dag;
            double regenpak = 10.00 * dag;
            double basis = 12.50 * dag;
            double uitgebreid = 20.00 * dag;

            //switch case voor elke situatie die voorkomt in de services combobox
            switch (services)
            {
                case "Ophaalservice € 15,00":
                    Listbox.Items.Add(services + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + ophaalservice);
                    totaalprijs += ophaalservice;
                    break;
                case "Regenpak € 10,00":
                    Listbox.Items.Add(services + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + regenpak);
                    totaalprijs += regenpak;
                    break;
                case "Lunchpakket basis	€ 12,50":
                    Listbox.Items.Add(services + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + basis);
                    totaalprijs += basis;
                    break;
                case "Lunchpakket uitgebreid € 20,00":
                    Listbox.Items.Add(services + ", " + "aantal dagen: " + aantal + ", " + "totaalprijs: € " + uitgebreid);
                    totaalprijs += uitgebreid;
                    break;
            }
            tbTotaal.Text = "€ "+ totaalprijs.ToString();
        }
        private void Button_VolgendeKlant(object sender, RoutedEventArgs e)
        {
            var listbox = Listbox;

            //Als de listbox count 0 is dan verschijnt er een messagebox
            if (listbox.Items.Count == 0)
            {
                MessageBox.Show("Selecteer eerst uw artikelen");
            }// er verschijnt een messagebox en als je op nee drukt dan kom je terug waar je gebleven was, voordat je op de knop drukte.  
            else if (MessageBox.Show("Is de bestelling betaald?","", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
            {
                return;
            }
            else //als je niet op nee drukt dan wordt deze code uitgevoerd
            {
                //bij selectedIndex = 0 deed het programma niks clearen bij -1 wel
                cbFietsen.SelectedIndex = -1;
                cbVerzekeringen.SelectedIndex = -1;
                cbServices.SelectedIndex = -1;
                tbAantal.Text = "1";
                tbTotaal.Text = "€0,00";
                Listbox.Items.Clear();
            }
        }
    }
 }
